/*
 * Copyright (c) 2022-2026 Vadym Hrynchyshyn <vadimgrn@gmail.com>
 */

#pragma once

/*
 * kmdf/1.27/wdfdevice.h(504)
 * warning C4471: '_WDF_REQUEST_TYPE': a forward declaration of an unscoped enumeration 
 * must have an underlying type.
 * P.S. Set C++ "All Options"/AdditionalOptions: /Zc:__cplusplus
 */
#if __cplusplus > 201703L
  enum _WDF_REQUEST_TYPE : int;
#endif

#include "codeseg.h"
#include <libusbip/generic_handle_ex.h>

#include <wdf.h>

namespace wdf
{

class ObjectRef
{
public:
        constexpr ObjectRef() = default;
        _IRQL_requires_same_
        _IRQL_requires_max_(DISPATCH_LEVEL)
        explicit ObjectRef(_In_opt_ WDFOBJECT handle, _In_ bool add_ref = true);

        _IRQL_requires_same_
        _IRQL_requires_max_(DISPATCH_LEVEL)
        ~ObjectRef();

        ObjectRef(const ObjectRef &obj) : ObjectRef(obj.m_handle) {}
        ObjectRef& operator =(const ObjectRef &obj);

        ObjectRef(ObjectRef &&obj) : m_handle(obj.release()) {}
        ObjectRef& operator =(ObjectRef &&obj);

        constexpr explicit operator bool() const { return m_handle; }
        constexpr auto operator !() const { return !m_handle; }

        constexpr bool operator ==(decltype(nullptr)) const { return m_handle == WDF_NO_HANDLE; }

        friend constexpr bool operator ==(const ObjectRef &a, const ObjectRef &b) { return a.m_handle == b.m_handle; }

        constexpr auto get(this auto&& self) { return self.m_handle; }
 
        template<typename T>
        constexpr auto get(this auto&& self) { return static_cast<T>(self.m_handle); }

        WDFOBJECT release();

        _IRQL_requires_same_
        _IRQL_requires_max_(DISPATCH_LEVEL)
        void reset(_In_opt_ WDFOBJECT handle = WDF_NO_HANDLE, _In_ bool add_ref = true);

        _IRQL_requires_same_
        _IRQL_requires_max_(DISPATCH_LEVEL)
        void swap(_Inout_ ObjectRef &r);

private:
        WDFOBJECT m_handle = WDF_NO_HANDLE;
};

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
inline void swap(_Inout_ ObjectRef &a, _Inout_ ObjectRef &b)
{
        a.swap(b);
}


class waitlock
{
public:
        constexpr waitlock() = default;
                
        _IRQL_requires_max_(PASSIVE_LEVEL)
        PAGED explicit waitlock(_In_ WDFWAITLOCK lock) : m_lock(lock) 
        { 
                PAGED_CODE();
                WdfWaitLockAcquire(m_lock, nullptr); 
        }

        _IRQL_requires_max_(DISPATCH_LEVEL)
        ~waitlock() { release(); }

        waitlock(_In_ const waitlock&) = delete;
        waitlock& operator =(_In_ const waitlock&) = delete;

        constexpr bool is_acquired() const { return m_lock != WDF_NO_HANDLE; }
        constexpr explicit operator bool() const { return is_acquired(); }

        _When_(timeout == NULL, _IRQL_requires_max_(PASSIVE_LEVEL))
        _When_(timeout != NULL && *timeout == 0, _IRQL_requires_max_(DISPATCH_LEVEL))
        _When_(timeout != NULL && *timeout != 0, _IRQL_requires_max_(PASSIVE_LEVEL))
        _When_(timeout != NULL, _Must_inspect_result_)
        NTSTATUS acquire(_In_ WDFWAITLOCK lock, _In_opt_ LONGLONG *timeout = nullptr);

        _IRQL_requires_max_(DISPATCH_LEVEL)
        void release()
        {
                if (m_lock) {
                        WdfWaitLockRelease(m_lock);
                        m_lock = WDF_NO_HANDLE;
                }
        }

private:
        WDFWAITLOCK m_lock = WDF_NO_HANDLE;
};


class spinlock
{
public:
        _IRQL_requires_max_(DISPATCH_LEVEL)
        _IRQL_raises_(DISPATCH_LEVEL)
        _IRQL_saves_global_(m_lock, this)
        explicit spinlock(
                _In_
                _Requires_lock_not_held_(_Curr_)
                _Acquires_lock_(_Curr_)
                _IRQL_saves_
                WDFSPINLOCK lock) : m_lock(lock)
        { 
                WdfSpinLockAcquire(m_lock);
        }

        _IRQL_requires_max_(DISPATCH_LEVEL)
        _IRQL_requires_min_(DISPATCH_LEVEL)
        _IRQL_restores_global_(m_lock, this)
        ~spinlock() { release(); }

        spinlock(_In_ const spinlock&) = delete;
        spinlock& operator =(_In_ const spinlock&) = delete;

        _IRQL_requires_max_(DISPATCH_LEVEL)
        _IRQL_requires_min_(DISPATCH_LEVEL)
        _IRQL_restores_global_(m_lock, this)
        void release()
        {
                if (m_lock != WDF_NO_HANDLE) {
                        WdfSpinLockRelease(m_lock);
                        m_lock = WDF_NO_HANDLE;
                }
        }

private:
        WDFSPINLOCK m_lock = WDF_NO_HANDLE;
};


struct wdfobject_traits
{
        static WDFOBJECT invalid() { return WDF_NO_HANDLE; }
};

struct wdfkey_traits
{
        static WDFKEY invalid() { return WDF_NO_HANDLE; }
};

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
inline void close_handle(_In_ WDFOBJECT obj, _In_ wdfobject_traits)
{
        WdfObjectDelete(obj);
}

_IRQL_requires_same_
_IRQL_requires_max_(PASSIVE_LEVEL)
inline void close_handle(_In_ WDFKEY key, _In_ wdfkey_traits)
{
        WdfRegistryClose(key);
}

using object_delete = usbip::generic_handle<wdfobject_traits>;
using registry = usbip::generic_handle<wdfkey_traits>;

} // namespace wdf
