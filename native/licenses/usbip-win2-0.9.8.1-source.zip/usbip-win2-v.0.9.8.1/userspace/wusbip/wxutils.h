/*
 * Copyright (c) 2023-2026 Vadym Hrynchyshyn <vadimgrn@gmail.com>
 */

#pragma once

#include <windows.h>
#include <wx/string.h>

#include <functional>
#include <stop_token>

class wxMenu;
class wxMenuItem;
class wxWindow;

wxMenuItem* clone_menu_item(_In_ wxMenu &dest, _In_ int item_id, _In_ const wxMenu &src);

namespace usbip
{

inline auto what(_In_ const std::exception &e)
{
        return wxString(e.what(), wxConvLibc);
}

using cancel_function = bool();
bool cancel_vhci_io();

void run_cancellable(
        _In_ wxWindow *parent,
        _In_ const wxString &msg,
        _In_ const wxString &caption,
        _In_ std::function<void(std::stop_token)> func,
        _In_ const std::function<cancel_function> &cancel = {});

} // namespace usbip

