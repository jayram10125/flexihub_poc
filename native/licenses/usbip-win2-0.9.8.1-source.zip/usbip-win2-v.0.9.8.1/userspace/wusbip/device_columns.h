/*
 * Copyright (c) 2024-2026 Vadym Hrynchyshyn <vadimgrn@gmail.com>
 */

#pragma once

#include <wx/string.h>
#include <array>

namespace usbip
{

enum class receive_mode;
struct persistent_device;
struct device_location;
struct imported_device;
struct device_state;

enum column_pos_t { // columns order in the tree
        COL_BUSID,
        COL_PORT,
        COL_SPEED,
        COL_VENDOR,
        COL_PRODUCT,
        COL_STATE,
        COL_PERSISTENT,
        COL_NOTES,
        COL_DEVID,
        COL_SERIAL,
        COL_RECEIVE_MODE,
        COL_LAST_VISIBLE = COL_RECEIVE_MODE,
        COL_SOURCE_ID, // hidden

        UPD_COL_FIRST = COL_PORT,
        UPD_COL_LAST  = COL_SOURCE_ID,
};

enum { // for device_columns only
        DEV_COL_URL = COL_SOURCE_ID + 1, // use get_url()
        DEV_COL_CNT
};

struct device_columns
{
        std::array<wxString, DEV_COL_CNT> values{};

        constexpr auto& operator[](this auto&& self, size_t idx) noexcept
        {
                return self.values[idx];
        }

        constexpr auto size() const noexcept { return values.size(); }
        constexpr auto begin(this auto&& self) noexcept { return self.values.begin(); }
        constexpr auto end(this auto&& self) noexcept { return self.values.end(); }
};

template<typename Array>
constexpr auto& get_url(_In_ Array &v) { return v[DEV_COL_URL]; }

constexpr auto mkflag(_In_ column_pos_t col) { return 1U << col; }

constexpr auto mkflags(_In_ std::initializer_list<column_pos_t> columns) noexcept
{
        auto flags = 0U;
        for (auto col: columns) {
                flags |= mkflag(col);
        }
        return flags;
}
static_assert(mkflags({COL_PORT, COL_SPEED, COL_VENDOR}) == 0b1110);

const wxString& to_string(_In_ receive_mode mode) noexcept;
receive_mode to_receive_mode(_In_ const wxString &mode) noexcept;
void validate_receive_mode(_Inout_ wxString &mode);

persistent_device make_persistent_device(_In_ const device_columns &dc);

persistent_device make_persistent_device(
        _In_ const wxString &url, _In_ const wxString &busid, _In_ const wxString &serial, _In_ const wxString &recv_mode);

std::pair<device_columns, unsigned int> make_device_columns(_In_ const imported_device &dev);
std::pair<device_columns, unsigned int> make_device_columns(_In_ const device_state &st);

bool is_empty(_In_ const imported_device &d) noexcept;
wxString to_wxstring(_In_ unsigned long source_id);

/*
 * @see make_cmp_key
 */
constexpr auto get_cmp_key(_In_ const device_columns &dc)
{
        return std::tie(get_url(dc), dc[COL_BUSID]); // tuple of lvalue references
}

constexpr auto operator == (_In_ const device_columns &a, _In_ const device_columns &b)
{
        return get_cmp_key(a) == get_cmp_key(b);
}

constexpr auto operator <=> (_In_ const device_columns &a, _In_ const device_columns &b)
{
        return get_cmp_key(a) <=> get_cmp_key(b);
}

} // namespace usbip
