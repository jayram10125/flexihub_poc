/*
 * Copyright (c) 2023-2026 Vadym Hrynchyshyn <vadimgrn@gmail.com>
 */

#include "int_dev_ctrl.h"
#include "trace.h"
#include "int_dev_ctrl.tmh"

#include "irp.h"
#include "request.h"
#include "driver.h"

#include <libdrv/remove_lock.h>
#include <libdrv/usbd_helper.h>
#include <libdrv/dbgcommon.h>
#include <libdrv/ioctl.h>
#include <libdrv/utils.h>
#include <libdrv/select.h>
#include <libdrv/urb_ptr.h>

using namespace usbip;
using namespace libdrv;

namespace
{

struct irp_args
{
        URB *urb;
        void *tag;
};

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
bool is_valid_urb_length(_In_ const URB &urb)
{
        auto &hdr = urb.UrbHeader;

        switch (hdr.Function) {
        case URB_FUNCTION_SYNC_RESET_PIPE_AND_CLEAR_STALL:
        case URB_FUNCTION_SYNC_RESET_PIPE:
        case URB_FUNCTION_SYNC_CLEAR_STALL:
                return hdr.Length == sizeof(urb.UrbPipeRequest);

        case URB_FUNCTION_SELECT_INTERFACE: {
                if (hdr.Length < offsetof(_URB_SELECT_INTERFACE, Interface)) {
                        return false;
                }

                auto &intf = urb.UrbSelectInterface.Interface;
                auto end = reinterpret_cast<const char*>(&urb) + hdr.Length;

                return is_valid(&intf, end);
        }
        }

        return false;
}


/*
 * DeviceObject can be NULL in exactly one situation: when a driver self-allocates an IRP
 * (e.g. via IoAllocateIrp) without an extra stack location and without manually stamping
 * its own device object into the current stack location before setting the completion routine.
 */
_Function_class_(IO_COMPLETION_ROUTINE)
_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
NTSTATUS request_complete(
	_In_ DEVICE_OBJECT*, _In_ IRP *irp, _In_reads_opt_(_Inexpressible_("varies")) void *context)
{
        auto &fltr = *static_cast<filter_ext*>(context);
        auto &args = get_params_others<irp_args>(IoGetCurrentIrpStackLocation(irp));

        remove_lock_guard lck(fltr.remove_lock, adopt_lock, args.tag);
        NT_ASSERT(lck.tag() != irp);

        irp_ptr rip(irp);
        urb_ptr urb(fltr.device.usbd_handle, args.urb);

        TraceDbg("dev %04x, irp %04x -> target %04x, %!STATUS!, USBD_STATUS_%s", ptr04x(fltr.self), 
                  ptr04x(irp), ptr04x(fltr.target), irp->IoStatus.Status, get_usbd_status(URB_STATUS(urb.get())));

        unique_ptr{urb->UrbControlTransferEx.TransferBuffer};
        return StopCompletion;
}

_IRQL_requires_max_(DISPATCH_LEVEL)
_IRQL_requires_same_
auto send_request(
	_In_ filter_ext &fltr, _Inout_ remove_lock_guard &lck, 
	_Inout_ unique_ptr &TransferBuffer, _In_ USHORT function)
{
	irp_ptr irp(fltr.target->StackSize + 1, false); // plus one for this driver's parameters
	if (!irp) {
		Trace(TRACE_LEVEL_ERROR, "IoAllocateIrp error");
		return STATUS_INSUFFICIENT_RESOURCES;
	}

        IoSetNextIrpStackLocation(irp.get());
        auto next = IoGetNextIrpStackLocation(irp.get());

        next->MajorFunction = IRP_MJ_INTERNAL_DEVICE_CONTROL;
        DeviceIoControlCode(next) = IOCTL_INTERNAL_USB_SUBMIT_URB;

	urb_ptr urb(fltr.device.usbd_handle);
	if (auto err = urb.alloc(next)) {
		Trace(TRACE_LEVEL_ERROR, "USBD_UrbAllocate %!STATUS!", err);
		return err;
	}

        IoSetCompletionRoutine(irp.get(), request_complete, &fltr, true, true, true);

        filter::pack_request(urb->UrbControlTransferEx, TransferBuffer.release(), function);

        auto &args = get_params_others<irp_args>(IoGetCurrentIrpStackLocation(irp.get()));
        args.urb = urb.release();
        args.tag = lck.clear();

        TraceDbg("dev %04x, irp %04x -> target %04x", ptr04x(fltr.self), ptr04x(irp.get()), ptr04x(fltr.target));
        return IoCallDriver(fltr.target, irp.release()); // completion routine will be called anyway
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
void send_urb(_In_ filter_ext &fltr, _Inout_ remove_lock_guard &lck, _In_ const URB &urb)
{
	if (auto &hdr = urb.UrbHeader; !is_valid_urb_length(urb)) {
		Trace(TRACE_LEVEL_ERROR, "Invalid URB length %lu", hdr.Length);
	} else if (auto buf = unique_ptr(uninitialized, NonPagedPoolNx, hdr.Length)) {
		RtlCopyMemory(buf.get(), &urb, hdr.Length);
		send_request(fltr, lck, buf, hdr.Function);
	} else {
		Trace(TRACE_LEVEL_ERROR, "Can't allocate %lu bytes", hdr.Length);
	}
}

/*
 * @see drivers/usb/usbip/stub_rx.c, tweak_set_configuration_cmd
 */
_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
void send_urb(_In_ filter_ext &fltr, _Inout_ remove_lock_guard &lck, _In_ const _URB_SELECT_CONFIGURATION &r)
{
	char buf[SELECT_CONFIGURATION_STR_BUFSZ];
	TraceDbg("dev %04x, %s", ptr04x(fltr.self), select_configuration_str(buf, sizeof(buf), &r));

        ULONG len{};
        if (unique_ptr ptr(clone(len, r, NonPagedPoolNx, unique_ptr::pooltag)); ptr) {
		send_request(fltr, lck, ptr, r.Hdr.Function);
	} else {
		Trace(TRACE_LEVEL_ERROR, "Can't allocate %lu bytes", len);
	}
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
void post_process_urb(_In_ filter_ext &fltr, _Inout_ remove_lock_guard &lck, _In_ const URB &urb)
{
	bool send{};
	
	switch (auto &hdr = urb.UrbHeader; hdr.Function) {
	using filter::is_request_function;
	case URB_FUNCTION_SYNC_RESET_PIPE_AND_CLEAR_STALL:
	case URB_FUNCTION_SYNC_RESET_PIPE:
	case URB_FUNCTION_SYNC_CLEAR_STALL: {
		static_assert(is_request_function(URB_FUNCTION_SYNC_RESET_PIPE_AND_CLEAR_STALL));
		static_assert(is_request_function(URB_FUNCTION_SYNC_RESET_PIPE));
		static_assert(is_request_function(URB_FUNCTION_SYNC_CLEAR_STALL));
		auto &r = urb.UrbPipeRequest;
		TraceDbg("dev %04x, %s, PipeHandle %04x", ptr04x(fltr.self), 
			  urb_function_str(hdr.Function), ptr04x(r.PipeHandle));
		send = true;
		break;
	}
	case URB_FUNCTION_SELECT_INTERFACE: {
		static_assert(is_request_function(URB_FUNCTION_SELECT_INTERFACE));
		auto &r = urb.UrbSelectInterface;
		char buf[SELECT_INTERFACE_STR_BUFSZ];
		TraceDbg("dev %04x, %s", ptr04x(fltr.self), select_interface_str(buf, sizeof(buf), r));
		send = true;
		break;
	}
	case URB_FUNCTION_SELECT_CONFIGURATION: {
		static_assert(is_request_function(URB_FUNCTION_SELECT_CONFIGURATION));
		send_urb(fltr, lck, urb.UrbSelectConfiguration);
		break;
	}
	default:
		TraceDbg("dev %04x, %s", ptr04x(fltr.self), urb_function_str(hdr.Function));
	}

	if (send) {
		send_urb(fltr, lck, urb);
	}
}

/*
// _URB_CONTROL_DESCRIPTOR_REQUEST 
case URB_FUNCTION_GET_DESCRIPTOR_FROM_DEVICE:
case URB_FUNCTION_GET_DESCRIPTOR_FROM_INTERFACE:
case URB_FUNCTION_GET_DESCRIPTOR_FROM_ENDPOINT:
//
case URB_FUNCTION_SET_DESCRIPTOR_TO_DEVICE:
case URB_FUNCTION_SET_DESCRIPTOR_TO_INTERFACE:
case URB_FUNCTION_SET_DESCRIPTOR_TO_ENDPOINT:

// _URB_CONTROL_FEATURE_REQUEST
case URB_FUNCTION_SET_FEATURE_TO_DEVICE:
case URB_FUNCTION_SET_FEATURE_TO_INTERFACE:
case URB_FUNCTION_SET_FEATURE_TO_ENDPOINT:
case URB_FUNCTION_SET_FEATURE_TO_OTHER:
//
case URB_FUNCTION_CLEAR_FEATURE_TO_DEVICE:
case URB_FUNCTION_CLEAR_FEATURE_TO_INTERFACE:
case URB_FUNCTION_CLEAR_FEATURE_TO_ENDPOINT:
case URB_FUNCTION_CLEAR_FEATURE_TO_OTHER:

// _URB_CONTROL_GET_STATUS_REQUEST 
case URB_FUNCTION_GET_STATUS_FROM_DEVICE:
case URB_FUNCTION_GET_STATUS_FROM_INTERFACE:
case URB_FUNCTION_GET_STATUS_FROM_ENDPOINT:
case URB_FUNCTION_GET_STATUS_FROM_OTHER:

case URB_FUNCTION_GET_CONFIGURATION: // _URB_CONTROL_GET_CONFIGURATION_REQUEST 
case URB_FUNCTION_GET_INTERFACE: // _URB_CONTROL_GET_INTERFACE_REQUEST 

case URB_FUNCTION_GET_MS_FEATURE_DESCRIPTOR: // _URB_OS_FEATURE_DESCRIPTOR_REQUEST
*/
constexpr auto get_request_type(_In_ const URB &urb)
{
        UCHAR bmRequestType;

        switch (urb.UrbHeader.Function) {
        case URB_FUNCTION_VENDOR_DEVICE:
                bmRequestType = USB_TYPE_VENDOR | USB_RECIP_DEVICE;
                break;
        case URB_FUNCTION_VENDOR_INTERFACE:
                bmRequestType = USB_TYPE_VENDOR | USB_RECIP_INTERFACE;
                break;
        case URB_FUNCTION_VENDOR_ENDPOINT:
                bmRequestType = USB_TYPE_VENDOR | USB_RECIP_ENDPOINT;
                break;
        case URB_FUNCTION_VENDOR_OTHER:
                bmRequestType = USB_TYPE_VENDOR | USB_RECIP_OTHER;
                break;
        case URB_FUNCTION_CLASS_DEVICE:
                bmRequestType = USB_TYPE_CLASS | USB_RECIP_DEVICE;
                break;
        case URB_FUNCTION_CLASS_INTERFACE:
                bmRequestType = USB_TYPE_CLASS | USB_RECIP_INTERFACE;
                break;
        case URB_FUNCTION_CLASS_ENDPOINT:
                bmRequestType = USB_TYPE_CLASS | USB_RECIP_ENDPOINT;
                break;
        case URB_FUNCTION_CLASS_OTHER:
                bmRequestType = USB_TYPE_CLASS | USB_RECIP_OTHER;
                break;
        default:
                return UCHAR{};
        }

        NT_ASSERT(bmRequestType);

        auto dir_in = IsTransferDirectionIn(urb.UrbControlVendorClassRequest.TransferFlags);
        bmRequestType |= (dir_in ? USB_DIR_IN : USB_DIR_OUT);

        return bmRequestType;
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
union legacy_ctrl_context
{
        void *as_context{};
        struct {
                USHORT function;
                USHORT reserved1;
                UCHAR request_type_reserved_bits;
        } s;
};
static_assert(sizeof(legacy_ctrl_context) == sizeof(void*));

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
auto vendor_class_to_control(_Inout_ URB &urb, _In_ UCHAR bmRequestType)
{
        auto &d = urb.UrbControlTransfer;
        auto &s = urb.UrbControlVendorClassRequest;

        static_assert(sizeof(d) == sizeof(s));
        NT_ASSERT(d.Hdr.Length == sizeof(d));

        legacy_ctrl_context ctx;
        ctx.s.function = s.Hdr.Function;
        ctx.s.reserved1 = s.Reserved1;
        ctx.s.request_type_reserved_bits = s.RequestTypeReservedBits;

        d.Hdr.Function = URB_FUNCTION_CONTROL_TRANSFER;
        // NT_ASSERT(!d.PipeHandle); // s.Reserved, fails for some devices

        NT_ASSERT(!(d.TransferFlags & USBD_DEFAULT_PIPE_TRANSFER));
        d.TransferFlags |= USBD_DEFAULT_PIPE_TRANSFER;

        s.RequestTypeReservedBits = bmRequestType;
        s.Reserved1 = static_cast<USHORT>(s.TransferBufferLength); // get_setup_packet(d).wLength

        NT_ASSERT(ctx.as_context);
        return ctx.as_context;
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
void control_to_vendor_class(_Inout_ URB &urb, _In_ void *context)
{
        legacy_ctrl_context ctx{ .as_context = context };
        auto &r = urb.UrbControlVendorClassRequest;

        r.Hdr.Function = ctx.s.function;
        r.TransferFlags &= ~USBD_DEFAULT_PIPE_TRANSFER; // clear flag
        r.RequestTypeReservedBits = ctx.s.request_type_reserved_bits;
        r.Reserved1 = ctx.s.reserved1;
}

/*
 * IRP -> usbip2_filter.sys -> ucx01000.sys -> udecx.sys -> usbip2_ude.sys
 * IRP can be completed by ucx01000 or udecx, in such case usbip2_ude will not receive it.
 * To detect such issues, all IRPs are inspected upon completion.
 */
_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
void post_process_irp(_In_ filter_ext &fltr, _Inout_ remove_lock_guard &lck, _In_ IRP *irp)
{
        auto status = irp->IoStatus.Status;

        if (auto ctl = DeviceIoControlCode(irp); ctl != IOCTL_INTERNAL_USB_SUBMIT_URB) {
                TraceDbg("dev %04x, %s, %!STATUS!", ptr04x(fltr.self), internal_device_control_name(ctl), status);

        } else if (auto urb = urb_from_irp(irp); !urb) {
                Trace(TRACE_LEVEL_ERROR, "dev %04x, submit URB has no URB pointer", ptr04x(fltr.self));

        } else if (!NT_SUCCESS(status) || USBD_ERROR(URB_STATUS(urb))) {
                auto &hdr = urb->UrbHeader;
                Trace(TRACE_LEVEL_ERROR, "dev %04x, %s, USBD_STATUS_%s, %!STATUS!", ptr04x(fltr.self), 
                        urb_function_str(hdr.Function), get_usbd_status(hdr.Status), status);
        } else {
                post_process_urb(fltr, lck, *urb);
        }
}

_Function_class_(IO_COMPLETION_ROUTINE)
_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
NTSTATUS irp_complete(
        _In_ DEVICE_OBJECT *devobj, _In_ IRP *irp, _In_reads_opt_(_Inexpressible_("varies")) void *context)
{
        auto &fltr = *get_filter_ext(devobj);
        remove_lock_guard lck(fltr.remove_lock, adopt_lock, irp);

        if (fltr.is_hub) {
                NT_ASSERT(!context);
        } else if (context) { // legacy control transfer
                auto urb = urb_from_irp(irp);
                control_to_vendor_class(*urb, context);
                TraceDbg("dev %04x, irp %04x, %!STATUS!, USBD_STATUS_%s", ptr04x(fltr.self),
                          ptr04x(irp), irp->IoStatus.Status, get_usbd_status(URB_STATUS(urb)));
        } else {
                post_process_irp(fltr, lck, irp);
        }

        if (irp->PendingReturned) {
                IoMarkIrpPending(irp);
        }

        return ContinueCompletion;
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
void* try_legacy_ctrl(_In_ filter_ext &fltr, _In_ IRP *irp, _Inout_ URB &urb)
{
        auto bmRequestType = get_request_type(urb);
        if (!bmRequestType) {
                return nullptr;
        }

        TraceDbg("dev %04x, irp %04x -> target %04x, %s", ptr04x(fltr.self), ptr04x(irp),
                  ptr04x(fltr.target), urb_function_str(urb.UrbHeader.Function));

        return vendor_class_to_control(urb, bmRequestType);
}

} // namespace


_IRQL_requires_max_(DISPATCH_LEVEL)
_IRQL_requires_same_
_Function_class_(DRIVER_DISPATCH)
_Dispatch_type_(IRP_MJ_INTERNAL_DEVICE_CONTROL)
NTSTATUS usbip::int_dev_ctrl(_In_ DEVICE_OBJECT *devobj, _In_ IRP *irp)
{
	auto &fltr = *get_filter_ext(devobj);

	remove_lock_guard lck(fltr.remove_lock, irp);
	if (!lck) {
		auto err = lck.status();
		Trace(TRACE_LEVEL_ERROR, "Acquire remove lock %!STATUS!", err);
		return CompleteRequest(irp, err);
	}

	void *ctx{};

	if (DeviceIoControlCode(irp) == IOCTL_INTERNAL_USB_SUBMIT_URB) {
		auto urb = urb_from_irp(irp);
		if (!urb) {
			Trace(TRACE_LEVEL_ERROR, "dev %04x, submit URB has no URB pointer", ptr04x(fltr.self));
			return CompleteRequest(irp, STATUS_INVALID_PARAMETER);
		}
		if (!fltr.is_hub) {
			ctx = try_legacy_ctrl(fltr, irp, *urb);
		}
	}

        IoCopyCurrentIrpStackLocationToNext(irp);
        IoSetCompletionRoutine(irp, irp_complete, ctx, true, true, true);

        lck.clear();
        return IoCallDriver(fltr.target, irp);
}
